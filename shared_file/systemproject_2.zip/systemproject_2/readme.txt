////////////////////////////////////////////////////////////////////////////////////////////////////////////

					PLAGARISM CHECKER 

////////////////////////////////////////////////////////////////////////////////////////////////////////////

1. File/Directory Structure
	a. Put all the sample files in one folder name it samples.
	b. Put samples folder in the folder of executable script "script.py" .
	c. All the sample files should be of .txt extention
	
2. other helper files function 
	a. parser - Parses the file by removing other lpha numeric characters
	b. documentdis - Find the similarity in the files by Document distance algo .
	c. editdis - Find the similarity in the files by Edit distance algo .
	d. lcs - Find the similarity in the files by Longest commmon subsequence algo .
	e. script - Run's the code with all necessary files integrated.
	f. fileheading - creates heading for the logfile

3. How to run
	Just run the executable script.py by typing following in the terminal. 
			"python sript.py"

4. Output in logstatus folder
	a. Contains one logfile correponding to one student showing its similarity score with all other student
	b. final_logfile.txt contains final result of plagarised or not plagarised document.
   
