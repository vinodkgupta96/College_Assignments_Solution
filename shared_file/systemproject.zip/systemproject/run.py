import os

direc = os.getcwd() # Get current working directory
ext = '.txt' # Select your file delimiter
direc=direc+'/samples'
#print direc
txt_files = [i for i in os.listdir(direc) if os.path.splitext(i)[1] == ext]
n=0

os.system("g++ -o fileheading fileheading.cpp")
os.system("g++ -o comparator comparator.cpp")

os.system("g++ -o editdis editdis.cpp")
#os.system("g++ -o comparator comparator.cpp")

# Iterate over your txt files
for f in txt_files:
	n=n+1
print n

for i in range(0,n):
	os.system("./fileheading "+txt_files[i])

for i in range(0,n):
	#print txt_files[i]	
	for j in range(i+1,n):
		os.system("./comparator "+txt_files[i]+" "+txt_files[j])


for i in range(0,n):
	#print txt_files[i]
	t=0	
	for j in range(0,n):
		if i == j:
			continue
		os.system("./editdis "+txt_files[i]+" "+txt_files[j]+" "+str(t))
		print "./editdis "+txt_files[i]+" "+txt_files[j]
		#print str(t)		
		t=t+1

########################################################################################################
########################################################################################################











































