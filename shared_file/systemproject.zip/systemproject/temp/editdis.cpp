/*

	Implementing Edit distance for finding the similarity between two document

	Treating the document in P paragraph and then applying Edit Distance between
	two submissions.

*/	  

#include<iostream>
#include<stdio.h>
#include<string.h>
#include<fstream>
#include<algorithm>
#include<limits.h>
using namespace std;
char a[2005],b[2005];
int dp[2005][2005];

int N=500;

int  min(int a,int b)
{
	if(a>b)
		return b;
	else 
		return a;
}

// function to check equality of characters

int fix(int i,int j)
{
	if(a[i-1]==b[j-1])
		return 0;
	else 
		return 1;
}


int main(int argc,char * argv[])
{

	char ch;
	int t,i,j;
	fstream ifile,ofile;
	int count=0;
	// opening both files
	int it=0;
	int flag=1;
	int total_edit=0;
	while(flag)
	{
		ifile.open(argv[1],ios::in);
		int cnt=-1;
	// Breaking both files in paragraphs of 500 words and then  applying Edit Distance on the files
		while(cnt!=count && ifile)
		{         
			i=0;
			while(ifile>>ch && i<N)
			{
				a[i++]=ch;
				//cout<<ch;
			}
			a[i]='\0';
			cnt++;
		}
		//cout<<"hi  ";
		//cout<<count<<"  "<<cnt<<"  bi\n";
		if(cnt!=count)
		{flag=0;break;}
		ofile.open(argv[2],ios::in);
		int minimum=INT_MAX;		
		while(ofile)
		{
			//ofile.open(argv[2],ios::in);
			it++;
			j=0;
			while(ofile>>ch && j<N)
			{
				b[j++]=ch;
			}
			b[j]='\0';
			int len=strlen(a);
			int len1=strlen(b);		
			//cout<<len<<"  "<<len1<<"\n";
			for(i=0;i<=len;i++)
			{
				for(j=0;j<=len1;j++)
				{
					if(i==0)
					{dp[i][j]=j;}						
					else if(j==0)
					{dp[i][j]=i;}
					else
					{
						long long int p=min(min(dp[i-1][j]+1,dp[i][j-1]+1),dp[i-1][j-1]+(fix(i,j)));
						dp[i][j]=p;
					}
				}

			}
			minimum=min(minimum,dp[len][len1]);
		//	printf("%d\n",dp[len][len1]);			
					
		}
		ofile.close();
		ifile.close();
		count++;
		printf("Minimum  %d\n",minimum);
		total_edit+=minimum;
	}
	cout<<"Total Edits required = "<<total_edit<<"\n";
	return 0;
} 

