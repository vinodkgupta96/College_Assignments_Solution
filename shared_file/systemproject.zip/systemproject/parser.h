#ifndef PARSER_H
#define PARSER_H
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <stdio.h>
using namespace std;

int parse(char a[],char b[])
{
  
 ofstream of;
  //char b[]="tmp.txt";
  of.open(b,ios::out|ios::trunc);
  of.close(); 
  
  //of.open(b,ios::out);
  
 ifstream f;
  f.open(a);
  if ( f.fail() )
  {
    cout << "Error: Cannot open file";// << strerror(errno);
    exit(0);
  }
  char ch;
  //ofstream of;
  //char b[]="tmp.txt";
  of.open(b,ios::out);
  int no_of_char=0;
  while(f) 
    {
      f >> ch;
      if(isalnum(ch))  
      {
       of << ch;
       no_of_char++;
      }
    }
cout<<"parser= 	"<<no_of_char<<"\n";  
return no_of_char;
  
}

#endif
