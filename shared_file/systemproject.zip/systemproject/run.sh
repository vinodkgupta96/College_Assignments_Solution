i=0
j=1
declare -a sample
for file in *
do
   #echo $i 
   $sample[i]}
   #echo $sample[i]
   i=$((i+1))
done
   echo $sample

