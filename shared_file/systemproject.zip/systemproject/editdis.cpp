/*

	Implementing Edit distance for finding the similarity between two document

	Treating the document in P paragraph and then applying Edit Distance between
	two submissions.

*/	  

#include<iostream>
#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<fstream>
#include<algorithm>
#include<limits.h>
#include "parser.h"
using namespace std;
char a[2005],b[2005];
int dp[2005][2005];

int N=500;

int  min(int a,int b)
{
  if(a>b)
    return b;
  else 
    return a;
}

// function to check equality of characters

int fix(int i,int j)
{
  if(a[i-1]==b[j-1])
    return 0;
  else 
    return 1;
}

void editdistance(char a[],char b[],int dp[][2005],int len,int len1)
{
  int i,j;
  for(i=0;i<=len;i++)
    {
      for(j=0;j<=len1;j++)
	{
	  if(i==0)
	    {dp[i][j]=j;}						
	  else if(j==0)
	    {dp[i][j]=i;}
	  else
	    {
	      long long int p=min(min(dp[i-1][j]+1,dp[i][j-1]+1),dp[i-1][j-1]+(fix(i,j)));
	      dp[i][j]=p;
	    }
	}
      
    }
}

int main(int argc,char * argv[])
{

 char str[50]; 
 getcwd(str, sizeof(str));
 strcat(str,"//samples");
 chdir(str); 


  char ch,f1[]="tmp1.txt",f2[]="tmp2.txt";
  int t,i,j;
  fstream ifile,ofile;
  int total_edit=0;
  int l1=parse(argv[1],f1);
  int l2=parse(argv[2],f2);
  if(l1<l2)
    {
      strcpy(f1,"tmp1.txt");
      strcpy(f2,"tmp2.txt");
    }
  else 
    {
      strcpy(f2,"tmp1.txt");
      strcpy(f1,"tmp2.txt");
    }
  ifile.open(f1,ios::in);
  while(ifile>>ch)
    {
      // Breaking both files in paragraphs of 500 words and then  applying Edit Distance on the files
      i=0;
      while(ifile>>ch && i<N)
	{
	  a[i++]=ch;
	}
	a[i]='\0';
	ofile.open(f2,ios::in);
	int minimum=INT_MAX;		
	while(ofile)
	  {
	    j=0;
	    while(ofile>>ch && j<N)
	      {
		b[j++]=ch;
	      }
	    b[j]='\0';
	    int len=strlen(a);
	    int len1=strlen(b);		
	    editdistance(a,b,dp,len,len1);
	    minimum=min(minimum,dp[len][len1]);
	  }
      ofile.close();
      //  printf("Minimum  %d\n",minimum);
      total_edit+=minimum;
    }
//if(argc == 3) 
 cout<<"Total Edits required = "<<total_edit<<"\n";

/////////////////////////////////////////////////////////////////////////////////////////////

/*
if(argc > 3)
{

fstream wfile1,wfile2,rfile1,rfile2;
  
 //  opening the file 
chdir("..");
 //char str[50]; 
 getcwd(str, sizeof(str));
 char stud1[50],stud2[50],path1[50],file1[50],file2[50];
 strcat(str,"//logstatus");
 //strcpy(path2,"\\home");
// cout<<str<<"\n";
 chdir(str); 
//cout<<str<<"\n";
 

 strcpy(stud1,argv[1]);
 strcpy(stud2,argv[2]);
 strcat(stud1,"_logfile.txt");
 strcat(stud2,"_logfile.txt");

 //strcat(path1,stud1);
 //strcat(path2,stud2);
 
  rfile1.open(stud1,ios::in|ios::out);
  //rfile2.open(stud2,ios::in);
 //wfile1.open(stud1,ios::out|ios::app);
  //wfile2.open(stud2,ios::out|ios::app);
 int cnt1,cnt2;
 float sim_score,edit_score,lcs_score;
 int t=atoi(argv[3]);
 cout<<t<<"\n";
 rfile1>>file1>>file1>>file1>>file1>>file1>>file1>>file1;
 while(t--)
 {
 	rfile1>>file1>>file2>>cnt1>>cnt2>>sim_score>>edit_score>>lcs_score;
//rfile1>>file1>>file2>>cnt1>>cnt2>>sim_score;
   	             
	//cout<<file1<<"  "<<file2<<"  "<<cnt1<<"  "<<cnt2<<"   "<<sim_score<<"  "<<edit_score<<"\n"; 
 }
 rfile1>>file1>>file2>>cnt1>>cnt2>>sim_score;
 rfile1<<"\t"<<total_edit<<"\t";
cout<<file1<<"  "<<file2<<"  "<<cnt1<<"  "<<cnt2<<"   "<<sim_score<<"  "<<edit_score<<"\n";

rfile1.close();
//cout<<file1<<"  "<<file2<<"  "<<cnt1<<"  "<<cnt2<<"   "<<sim_score<<"  "<<edit_score<<"\n"; 
 //wfile1<<argv[1]<<"\t"<<argv[2]<<"\t"<<cnt1<<"\t"<<cnt2<<"\t"<<sim_score<<"\t"<<total_edit<<"\n"; 
}

*/
//////////////////////////////////////////////////////////////////////////////////////////////


  return 0;
}
