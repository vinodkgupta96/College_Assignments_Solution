/*

	Implementing Document distance for finding the similarity between two document

	Treating the document as a N  dimentional vector and finding distance
	measure between two submissions

*/	  

#include<iostream>
#include<fstream>
#include<map>
#include<string.h>
#include<string>
#include<math.h>
#include<stdio.h>
#include<unistd.h>
#define piby2 1.5708
using namespace std;




int main(int argc,char * argv[])
{
 
char str[50]; 
 getcwd(str, sizeof(str));
 strcat(str,"//samples");
 chdir(str); 


 fstream ifile,ofile;
  
 //  opening the file
 //cout<<str<<"\n";  
ifile.open(argv[1],ios::in);
  ofile.open(argv[2],ios::in);
  string s;
  int cnt1=0,cnt2=0;
  map <string,int> m,m1,m2;
 
 //reading file 1
 while(ifile>>s)
  {
    m[s]=0;
     m1[s]++;
     cnt1++;
     // cout<<s<<"\n";
  }

 //reading file 2
  while(ofile>>s)
  {
    m[s]=0;
     m2[s]++;
     cnt2++;
     //   cout<<s<<"\n";
  }

  double dot=0,mod1=0,mod2=0,costheta=0;
  
 // Calculating disatance between two documents using dot product as distance measure 

  map<string,int> :: iterator it;
  for(it=m.begin();it!=m.end();it++)
   {
     
     //      cout<<it->first<<"   "<<m1[it->first]<<"   "<<m2[it->first]<<"\n";
     double a,b;
     a=m1[it->first];
     b=m2[it->first];
     dot+=a*b;
     mod1+=(a*a);
     mod2+=(b*b);
     // cout<<dot<<"\n";
   }
 
  costheta=dot/(sqrt(mod1)*sqrt(mod2));
 float sim_score=1 - acos(costheta)/piby2;
 float edit_score,lcs_score;
  // cout<<costheta<<"  "<<mod1<<"  "<<mod2<<"\n";
  // cout<<"Similarity score is = "<<"  "<<acos(costheta)<<"  "<<1-acos(costheta)/piby2<<"\n";
  //cout<<"Similarity score is = "<<1-acos(costheta)/piby2<<"\n";
//  cout << "words in doc 1 : " << cnt1 << "  Words in doc2 : " << cnt2 << "\n";
//  cout << "Distance between docs is :" << 1 - acos(costheta)/piby2<< "\n";
   

/////////////////////////edit dis














//////////////////////////////



 fstream wfile1,wfile2;
  
 //  opening the file 
 chdir("..");
 //char str[50]; 
 getcwd(str, sizeof(str));
 char stud1[50],stud2[50],path1[50];
 strcat(str,"//logstatus");
 //strcpy(path2,"\\home");
// cout<<str<<"\n";
 chdir(str); 
//cout<<str<<"\n";
 

 strcpy(stud1,argv[1]);
 strcpy(stud2,argv[2]);
 strcat(stud1,"_logfile.txt");
 strcat(stud2,"_logfile.txt");

 //strcat(path1,stud1);
 //strcat(path2,stud2);
 
 
  wfile1.open(stud1,ios::out|ios::app);
  wfile2.open(stud2,ios::out|ios::app);

 wfile1<<argv[1]<<"\t"<<argv[2]<<"\t"<<cnt1<<"\t"<<cnt2<<"\t"<<sim_score<<"\t"<<tmp<<"\t"<<tmp<<"\n";  
  wfile2<<argv[2]<<"\t"<<argv[1]<<"\t"<<cnt2<<"\t"<<cnt1<<"\t"<<sim_score<<"\t"<<tmp<<"\t"<<tmp<<"\n"; 
 //wfile.fclose();
//   wfile1<<sim_score<<"\n";
 return 0;
}
